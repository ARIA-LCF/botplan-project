import logging
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from google.auth.exceptions import RefreshError
from datetime import datetime, timedelta
import pytz
from app.core.config import settings
from app.core.database import get_db
from app.models.user import User
import json

logger = logging.getLogger(__name__)

class GoogleCalendarSync:
    def __init__(self):
        self.tehran_tz = pytz.timezone(settings.timezone)
    
    async def get_user_credentials(self, user_id: int):
        """Get user's Google OAuth credentials from database"""
        db = next(get_db())
        # In a real implementation, you'd store tokens in a separate table
        # For now, we'll return None - you need to implement OAuth flow
        return None
    
    async def create_schedule_event(self, user: User, schedule):
        """Create Google Calendar event for a schedule"""
        try:
            credentials = await self.get_user_credentials(user.id)
            if not credentials:
                logger.warning(f"No Google credentials for user {user.id}")
                return None
            
            service = build('calendar', 'v3', credentials=credentials)
            
            # Calculate event start and end times
            event_start = self._get_next_occurrence(schedule.day_of_week, schedule.start_time)
            event_end = self._get_next_occurrence(schedule.day_of_week, schedule.end_time)
            
            event = {
                'summary': f"📅 {schedule.task_name}",
                'description': schedule.task_description or f"برنامه هفتگی: {schedule.task_name}",
                'start': {
                    'dateTime': event_start.isoformat(),
                    'timeZone': settings.timezone,
                },
                'end': {
                    'dateTime': event_end.isoformat(),
                    'timeZone': settings.timezone,
                },
                'recurrence': [
                    'RRULE:FREQ=WEEKLY'
                ],
                'reminders': {
                    'useDefault': False,
                    'overrides': [
                        {'method': 'popup', 'minutes': 5},  # 5 minutes before
                    ],
                },
                'colorId': self._get_color_id(schedule.color),
            }
            
            created_event = service.events().insert(
                calendarId='primary',
                body=event
            ).execute()
            
            logger.info(f"Google Calendar event created: {created_event['id']}")
            return created_event['id']
            
        except Exception as e:
            logger.error(f"Error creating Google Calendar event: {e}")
            return None
    
    async def create_alarm_event(self, user: User, alarm):
        """Create Google Calendar event for an alarm"""
        try:
            credentials = await self.get_user_credentials(user.id)
            if not credentials:
                logger.warning(f"No Google credentials for user {user.id}")
                return None
            
            service = build('calendar', 'v3', credentials=credentials)
            
            event = {
                'summary': f"⏰ {alarm.message}",
                'description': f"آلارم: {alarm.message}",
                'start': {
                    'dateTime': alarm.alarm_time.isoformat(),
                    'timeZone': settings.timezone,
                },
                'end': {
                    'dateTime': (alarm.alarm_time + timedelta(minutes=5)).isoformat(),
                    'timeZone': settings.timezone,
                },
                'reminders': {
                    'useDefault': False,
                    'overrides': [
                        {'method': 'popup', 'minutes': 0},  # At time of event
                    ],
                },
            }
            
            # Add recurrence for repeating alarms
            if alarm.repeat_pattern != "ONCE":
                recurrence_rule = self._get_recurrence_rule(alarm)
                if recurrence_rule:
                    event['recurrence'] = [recurrence_rule]
            
            created_event = service.events().insert(
                calendarId='primary',
                body=event
            ).execute()
            
            logger.info(f"Google Calendar alarm event created: {created_event['id']}")
            return created_event['id']
            
        except Exception as e:
            logger.error(f"Error creating Google Calendar alarm event: {e}")
            return None
    
    async def update_schedule_event(self, user: User, schedule):
        """Update existing Google Calendar event for schedule"""
        if not schedule.google_event_id:
            return await self.create_schedule_event(user, schedule)
        
        try:
            credentials = await self.get_user_credentials(user.id)
            if not credentials:
                return None
            
            service = build('calendar', 'v3', credentials=credentials)
            
            # Get existing event
            existing_event = service.events().get(
                calendarId='primary',
                eventId=schedule.google_event_id
            ).execute()
            
            # Update event details
            event_start = self._get_next_occurrence(schedule.day_of_week, schedule.start_time)
            event_end = self._get_next_occurrence(schedule.day_of_week, schedule.end_time)
            
            existing_event['summary'] = f"📅 {schedule.task_name}"
            existing_event['description'] = schedule.task_description or f"برنامه هفتگی: {schedule.task_name}"
            existing_event['start']['dateTime'] = event_start.isoformat()
            existing_event['end']['dateTime'] = event_end.isoformat()
            existing_event['colorId'] = self._get_color_id(schedule.color)
            
            updated_event = service.events().update(
                calendarId='primary',
                eventId=schedule.google_event_id,
                body=existing_event
            ).execute()
            
            logger.info(f"Google Calendar event updated: {updated_event['id']}")
            return updated_event['id']
            
        except Exception as e:
            logger.error(f"Error updating Google Calendar event: {e}")
            return None
    
    async def update_alarm_event(self, user: User, alarm):
        """Update existing Google Calendar event for alarm"""
        if not alarm.google_event_id:
            return await self.create_alarm_event(user, alarm)
        
        try:
            credentials = await self.get_user_credentials(user.id)
            if not credentials:
                return None
            
            service = build('calendar', 'v3', credentials=credentials)
            
            # Get existing event
            existing_event = service.events().get(
                calendarId='primary',
                eventId=alarm.google_event_id
            ).execute()
            
            # Update event details
            existing_event['summary'] = f"⏰ {alarm.message}"
            existing_event['description'] = f"آلارم: {alarm.message}"
            existing_event['start']['dateTime'] = alarm.alarm_time.isoformat()
            existing_event['end']['dateTime'] = (alarm.alarm_time + timedelta(minutes=5)).isoformat()
            
            # Update recurrence
            if alarm.repeat_pattern != "ONCE":
                recurrence_rule = self._get_recurrence_rule(alarm)
                if recurrence_rule:
                    existing_event['recurrence'] = [recurrence_rule]
            else:
                existing_event.pop('recurrence', None)
            
            updated_event = service.events().update(
                calendarId='primary',
                eventId=alarm.google_event_id,
                body=existing_event
            ).execute()
            
            logger.info(f"Google Calendar alarm event updated: {updated_event['id']}")
            return updated_event['id']
            
        except Exception as e:
            logger.error(f"Error updating Google Calendar alarm event: {e}")
            return None
    
    async def delete_schedule_event(self, user: User, event_id: str):
        """Delete Google Calendar event for schedule"""
        try:
            credentials = await self.get_user_credentials(user.id)
            if not credentials:
                return
            
            service = build('calendar', 'v3', credentials=credentials)
            
            service.events().delete(
                calendarId='primary',
                eventId=event_id
            ).execute()
            
            logger.info(f"Google Calendar event deleted: {event_id}")
            
        except Exception as e:
            logger.error(f"Error deleting Google Calendar event: {e}")
    
    async def delete_alarm_event(self, user: User, event_id: str):
        """Delete Google Calendar event for alarm"""
        try:
            credentials = await self.get_user_credentials(user.id)
            if not credentials:
                return
            
            service = build('calendar', 'v3', credentials=credentials)
            
            service.events().delete(
                calendarId='primary',
                eventId=event_id
            ).execute()
            
            logger.info(f"Google Calendar alarm event deleted: {event_id}")
            
        except Exception as e:
            logger.error(f"Error deleting Google Calendar alarm event: {e}")
    
    def _get_next_occurrence(self, day_of_week: int, time_obj):
        """Get next occurrence of a weekly schedule"""
        today = datetime.now(self.tehran_tz)
        current_weekday = today.weekday()
        
        # Convert to Persian weekday (0=Saturday)
        persian_weekday = day_of_week
        
        # Calculate days until next occurrence
        days_until = (persian_weekday - current_weekday) % 7
        if days_until == 0 and today.time() > time_obj:
            days_until = 7  # Next week
        
        next_date = today + timedelta(days=days_until)
        next_datetime = datetime.combine(next_date.date(), time_obj)
        return self.tehran_tz.localize(next_datetime)
    
    def _get_color_id(self, color_hex: str):
        """Map hex color to Google Calendar colorId"""
        color_map = {
            '#3b82f6': '1',  # Blue
            '#10b981': '2',  # Green
            '#f59e0b': '5',  # Yellow
            '#8b5cf6': '6',  # Purple
            '#ef4444': '4',  # Red
            '#6b7280': '8',  # Gray
        }
        return color_map.get(color_hex, '1')
    
    def _get_recurrence_rule(self, alarm):
        """Generate recurrence rule for repeating alarms"""
        if alarm.repeat_pattern == "DAILY":
            return "RRULE:FREQ=DAILY"
        elif alarm.repeat_pattern == "WEEKLY" and alarm.repeat_days:
            days_map = {'0': 'SU', '1': 'MO', '2': 'TU', '3': 'WE', '4': 'TH', '5': 'FR', '6': 'SA'}
            day_list = [days_map[d] for d in alarm.repeat_days.split(',') if d in days_map]
            if day_list:
                return f"RRULE:FREQ=WEEKLY;BYDAY={','.join(day_list)}"
        elif alarm.repeat_pattern == "MONTHLY":
            return "RRULE:FREQ=MONTHLY"
        elif alarm.repeat_pattern == "YEARLY":
            return "RRULE:FREQ=YEARLY"
        
        return None

# Global instance
google_calendar_sync = GoogleCalendarSync()