import jdatetime
from datetime import datetime, timedelta
import pytz
from app.core.config import settings

class PersianCalendarService:
    def __init__(self):
        self.tehran_tz = pytz.timezone(settings.timezone)
    
    def get_current_persian_datetime(self):
        """Get current datetime in Persian calendar"""
        now_utc = datetime.utcnow()
        now_tehran = now_utc.astimezone(self.tehran_tz)
        persian_date = jdatetime.datetime.fromgregorian(datetime=now_tehran)
        return persian_date
    
    def get_persian_weekday_name(self, day_number):
        """Get Persian name of weekday (0=Saturday, 6=Friday)"""
        weekdays = {
            0: "شنبه",
            1: "یکشنبه", 
            2: "دوشنبه",
            3: "سه‌شنبه",
            4: "چهارشنبه",
            5: "پنجشنبه",
            6: "جمعه"
        }
        return weekdays.get(day_number, "نامشخص")
    
    def get_weekday_number(self, persian_name):
        """Get weekday number from Persian name"""
        weekdays = {
            "شنبه": 0,
            "یکشنبه": 1,
            "دوشنبه": 2,
            "سه‌شنبه": 3,
            "چهارشنبه": 4,
            "پنجشنبه": 5,
            "جمعه": 6
        }
        return weekdays.get(persian_name, 0)
    
    def gregorian_to_persian(self, gregorian_date):
        """Convert Gregorian date to Persian"""
        return jdatetime.datetime.fromgregorian(datetime=gregorian_date)
    
    def persian_to_gregorian(self, persian_date):
        """Convert Persian date to Gregorian"""
        return persian_date.togregorian()
    
    def get_week_start_end(self, date=None):
        """Get start and end of week for a given date"""
        if date is None:
            date = self.get_current_persian_datetime()
        
        week_start = date - timedelta(days=date.weekday())
        week_end = week_start + timedelta(days=6)
        
        return week_start, week_end
    
    def format_persian_date(self, persian_date, format_str="%Y/%m/%d"):
        """Format Persian date to string"""
        return persian_date.strftime(format_str)

# Global instance
persian_calendar = PersianCalendarService()