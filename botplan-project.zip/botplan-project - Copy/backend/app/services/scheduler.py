import logging
from datetime import datetime, timedelta
from celery import Celery
from celery.schedules import crontab
import pytz
from app.core.config import settings
from app.services.notification import NotificationService
from app.core.database import get_db
from app.models.schedule import WeeklySchedule
from app.models.alarm import Alarm
from app.models.analytics import TaskLog

logger = logging.getLogger(__name__)

# Celery app
celery_app = Celery('botplan', broker=settings.redis_url)
celery_app.conf.timezone = settings.timezone

class SchedulerService:
    def __init__(self):
        self.tehran_tz = pytz.timezone(settings.timezone)
        self.notification_service = NotificationService()
    
    def setup_periodic_tasks(self):
        """Setup periodic tasks for Celery beat"""
        celery_app.conf.beat_schedule = {
            # Check every minute for due alarms and schedules
            'check-due-tasks-every-minute': {
                'task': 'app.services.scheduler.check_due_tasks',
                'schedule': crontab(minute='*'),
            },
            # Cleanup old logs every day at 2 AM
            'cleanup-old-logs-daily': {
                'task': 'app.services.scheduler.cleanup_old_logs',
                'schedule': crontab(hour=2, minute=0),
            },
        }
    
    @celery_app.task
    def check_due_tasks():
        """Check for due tasks and send notifications"""
        try:
            service = SchedulerService()
            now = datetime.now(service.tehran_tz)
            
            # Check schedules
            service._check_due_schedules(now)
            
            # Check alarms
            service._check_due_alarms(now)
            
        except Exception as e:
            logger.error(f"Error in check_due_tasks: {e}")
    
    def _check_due_schedules(self, now):
        """Check for due schedules"""
        db = next(get_db())
        
        # Get current time info
        current_weekday = now.weekday()  # 0=Monday, 6=Sunday
        current_time = now.time()
        
        # Convert to Persian weekday if needed (0=Saturday)
        persian_weekday = (current_weekday + 2) % 7
        
        # Find schedules for current day and time
        schedules = db.query(WeeklySchedule).filter(
            WeeklySchedule.day_of_week == persian_weekday,
            WeeklySchedule.is_active == True
        ).all()
        
        for schedule in schedules:
            # Check if it's time for reminder (5 minutes before)
            reminder_time = (datetime.combine(now.date(), schedule.start_time) - 
                           timedelta(minutes=5)).time()
            
            # Check if it's exact start time
            if current_time == schedule.start_time:
                self._send_schedule_notification(schedule, "start", now)
            elif current_time == reminder_time:
                self._send_schedule_notification(schedule, "reminder", now)
    
    def _check_due_alarms(self, now):
        """Check for due alarms"""
        db = next(get_db())
        
        # Find alarms that are due
        alarms = db.query(Alarm).filter(
            Alarm.alarm_time <= now,
            Alarm.is_active == True
        ).all()
        
        for alarm in alarms:
            self._send_alarm_notification(alarm, now)
    
    def _send_schedule_notification(self, schedule, notification_type, now):
        """Send schedule notification"""
        try:
            message = ""
            if notification_type == "reminder":
                message = f"⏰ یادآوری: ۵ دقیقه تا '{schedule.task_name}' باقی مانده"
            else:
                message = f"📅 زمان '{schedule.task_name}' فرا رسیده است"
            
            # Send via Telegram
            self.notification_service.send_telegram_message(
                schedule.user.telegram_id, 
                message
            )
            
            # Log the notification
            self._log_notification(schedule.user_id, schedule.id, "schedule", now, notification_type)
            
            logger.info(f"Schedule notification sent: {message}")
            
        except Exception as e:
            logger.error(f"Error sending schedule notification: {e}")
    
    def _send_alarm_notification(self, alarm, now):
        """Send alarm notification"""
        try:
            message = f"⏰ آلارم: {alarm.message}"
            
            # Send via Telegram
            self.notification_service.send_telegram_message(
                alarm.user.telegram_id,
                message
            )
            
            # Log the notification
            self._log_notification(alarm.user_id, alarm.id, "alarm", now, "alarm")
            
            # Deactivate one-time alarms
            if alarm.repeat_pattern == "ONCE":
                alarm.is_active = False
                db = next(get_db())
                db.commit()
            
            logger.info(f"Alarm notification sent: {message}")
            
        except Exception as e:
            logger.error(f"Error sending alarm notification: {e}")
    
    def _log_notification(self, user_id, task_id, task_type, timestamp, status):
        """Log notification in database"""
        try:
            db = next(get_db())
            
            task_log = TaskLog(
                user_id=user_id,
                task_id=task_id,
                task_type=task_type,
                scheduled_time=timestamp,
                executed_time=datetime.now(self.tehran_tz),
                status=status
            )
            
            db.add(task_log)
            db.commit()
            
        except Exception as e:
            logger.error(f"Error logging notification: {e}")
    
    @celery_app.task
    def cleanup_old_logs():
        """Cleanup old task logs (keep only last 90 days)"""
        try:
            db = next(get_db())
            cutoff_date = datetime.now() - timedelta(days=90)
            
            deleted_count = db.query(TaskLog).filter(
                TaskLog.created_at < cutoff_date
            ).delete()
            
            db.commit()
            logger.info(f"Cleaned up {deleted_count} old task logs")
            
        except Exception as e:
            logger.error(f"Error cleaning up old logs: {e}")

# Initialize scheduler
scheduler_service = SchedulerService()
scheduler_service.setup_periodic_tasks()