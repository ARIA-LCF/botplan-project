import logging
from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from app.core.config import settings
from app.core.database import get_db
from app.models.user import User
from sqlalchemy.orm import Session
import os

logger = logging.getLogger(__name__)

# Global bot instance
bot_application = None

class TelegramBotService:
    def __init__(self):
        self.token = settings.telegram_bot_token
        self.application = None
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handler for /start command"""
        user = update.effective_user
        logger.info(f"Start command from user: {user.id} - {user.first_name}")
        
        # ذخیره کاربر در دیتابیس
        db = next(get_db())
        existing_user = db.query(User).filter(User.telegram_id == user.id).first()
        
        if not existing_user:
            new_user = User(
                telegram_id=user.id,
                first_name=user.first_name,
                username=user.username,
                is_active=True
            )
            db.add(new_user)
            db.commit()
            welcome_message = f"""🎉 به BotPlan خوش آمدی {user.first_name}!

🤖 من دستیار برنامه‌ریزی تو هستم که کمک می‌کنم:
• 📅 برنامه هفتگی تنظیم کنی
• ⏰ آلارم یادآوری بگیری  
• 📊 عملکردت رو آنالیز کنی

💡 برای شروع از دستورات زیر استفاده کن:"""
        else:
            welcome_message = f"""👋 سلام {user.first_name}!

دستورات در دسترس:"""
        
        keyboard = [
            [InlineKeyboardButton("📅 برنامه هفتگی", callback_data="view_schedule")],
            [InlineKeyboardButton("⏰ تنظیم آلارم", callback_data="set_alarm")],
            [InlineKeyboardButton("📊 مشاهده آمار", callback_data="view_analytics")],
            [InlineKeyboardButton("⚙️ تنظیمات", callback_data="settings")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    
    async def view_schedule(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش برنامه هفتگی کاربر"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        db = next(get_db())
        
        # دریافت برنامه‌های کاربر از دیتابیس
        # (این قسمت بعداً تکمیل می‌شود)
        
        await query.edit_message_text(
            "📅 برنامه هفتگی تو:\n\n"
            "🔄 این بخش به زودی تکمیل می‌شود...",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]])
        )
    
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handler for inline keyboard buttons"""
        query = update.callback_query
        callback_data = query.data
        
        if callback_data == "view_schedule":
            await self.view_schedule(update, context)
        elif callback_data == "set_alarm":
            await self.set_alarm(update, context)
        elif callback_data == "view_analytics":
            await self.view_analytics(update, context)
        elif callback_data == "settings":
            await self.settings(update, context)
        elif callback_data == "main_menu":
            await self.start(update, context)
    
    async def set_alarm(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """تنظیم آلارم جدید"""
        query = update.callback_query
        await query.answer()
        
        await query.edit_message_text(
            "⏰ برای تنظیم آلارم جدید، پیام رو به این فرمت ارسال کن:\n\n"
            "`/alarm 14:30 جلسه با تیم`\n\n"
            "یا از منوی زیر انتخاب کن:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏰ آلارم سریع (۱ ساعت دیگر)", callback_data="quick_alarm")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
            ]),
            parse_mode="Markdown"
        )
    
    async def view_analytics(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """نمایش آمار و آنالیز"""
        query = update.callback_query
        await query.answer()
        
        await query.edit_message_text(
            "📊 آمار و عملکرد تو:\n\n"
            "🔄 این بخش به زودی تکمیل می‌شود...",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]])
        )
    
    async def settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """منوی تنظیمات"""
        query = update.callback_query
        await query.answer()
        
        await query.edit_message_text(
            "⚙️ تنظیمات:\n\n"
            "🔄 این بخش به زودی تکمیل می‌شود...",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]])
        )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handler for text messages"""
        message_text = update.message.text
        
        if message_text.startswith('/alarm'):
            await self.create_alarm_from_message(update, context)
        else:
            await update.message.reply_text(
                "🤔 متوجه نشدم! از دستورات یا دکمه‌های منوی اصلی استفاده کن.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📋 منوی اصلی", callback_data="main_menu")]])
            )
    
    async def create_alarm_from_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """ایجاد آلارم از پیام کاربر"""
        # پیاده‌سازی ایجاد آلارم
        await update.message.reply_text("✅ آلارم با موفقیت تنظیم شد!")

async def start_bot():
    """Start the Telegram bot"""
    global bot_application
    
    if not settings.telegram_bot_token:
        logger.warning("Telegram bot token not set - bot will not start")
        return
    
    try:
        bot_service = TelegramBotService()
        bot_application = Application.builder().token(settings.telegram_bot_token).build()
        
        # Add handlers
        bot_application.add_handler(CommandHandler("start", bot_service.start))
        bot_application.add_handler(CallbackQueryHandler(bot_service.button_handler))
        bot_application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, bot_service.handle_message))
        
        # Start bot
        await bot_application.initialize()
        await bot_application.start()
        await bot_application.updater.start_polling()
        
        logger.info("Telegram bot started successfully")
    except Exception as e:
        logger.error(f"Error starting Telegram bot: {e}")

async def stop_bot():
    """Stop the Telegram bot"""
    global bot_application
    if bot_application:
        await bot_application.updater.stop()
        await bot_application.stop()
        await bot_application.shutdown()
        logger.info("Telegram bot stopped")