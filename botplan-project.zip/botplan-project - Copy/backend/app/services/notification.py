import logging
from telegram import Bot
from app.core.config import settings

logger = logging.getLogger(__name__)

class NotificationService:
    def __init__(self):
        self.bot = None
        if settings.telegram_bot_token:
            try:
                self.bot = Bot(token=settings.telegram_bot_token)
            except Exception as e:
                logger.error(f"Error initializing Telegram bot: {e}")
    
    def send_telegram_message(self, chat_id, message):
        """Send message via Telegram"""
        if not self.bot:
            logger.warning("Telegram bot not initialized")
            return False
        
        try:
            self.bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="HTML"
            )
            return True
        except Exception as e:
            logger.error(f"Error sending Telegram message: {e}")
            return False
    
    def send_reminder(self, user, task, minutes_before=5):
        """Send reminder notification"""
        message = f"""
⏰ یادآوری: {minutes_before} دقیقه دیگر
📌 کار: {task.task_name}
⏰ زمان: {task.start_time.strftime('%H:%M')}
        """.strip()
        
        return self.send_telegram_message(user.telegram_id, message)
    
    def send_alarm(self, user, alarm):
        """Send alarm notification"""
        message = f"""
🔔 آلارم: {alarm.message}
⏰ زمان: {alarm.alarm_time.strftime('%Y/%m/%d %H:%M')}
        """.strip()
        
        return self.send_telegram_message(user.telegram_id, message)

# Global instance
notification_service = NotificationService()