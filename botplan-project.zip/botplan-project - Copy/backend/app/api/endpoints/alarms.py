from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
from app.core.database import get_db
from app.models.user import User
from app.models.alarm import Alarm
from app.api.endpoints.auth import get_current_user
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic models
class AlarmCreate(BaseModel):
    alarm_time: str  # Format: "YYYY-MM-DD HH:MM" or "HH:MM" for today
    message: str
    repeat_pattern: Optional[str] = "ONCE"  # ONCE, DAILY, WEEKLY, MONTHLY, YEARLY
    repeat_days: Optional[str] = None  # For WEEKLY: "0,2,4" for Sat, Mon, Wed

class AlarmResponse(BaseModel):
    id: int
    alarm_time: str
    message: str
    repeat_pattern: str
    repeat_days: Optional[str]
    is_active: bool
    google_event_id: Optional[str]
    
    class Config:
        from_attributes = True

class AlarmUpdate(BaseModel):
    alarm_time: Optional[str] = None
    message: Optional[str] = None
    repeat_pattern: Optional[str] = None
    repeat_days: Optional[str] = None
    is_active: Optional[bool] = None

@router.get("/", response_model=List[AlarmResponse])
async def get_alarms(
    active_only: bool = True,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's alarms"""
    query = db.query(Alarm).filter(Alarm.user_id == current_user.id)
    
    if active_only:
        query = query.filter(Alarm.is_active == True)
    
    alarms = query.order_by(Alarm.alarm_time).all()
    return alarms

@router.post("/", response_model=AlarmResponse)
async def create_alarm(
    alarm_data: AlarmCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new alarm"""
    try:
        # Parse alarm time
        if len(alarm_data.alarm_time) == 5:  # HH:MM format
            today = datetime.now().date()
            alarm_time_str = f"{today} {alarm_data.alarm_time}"
            alarm_time = datetime.fromisoformat(alarm_time_str)
        else:
            alarm_time = datetime.fromisoformat(alarm_data.alarm_time)
        
        # Ensure alarm time is in future
        if alarm_time < datetime.now():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Alarm time must be in the future"
            )
        
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid time format. Use YYYY-MM-DD HH:MM or HH:MM"
        )
    
    # Create new alarm
    new_alarm = Alarm(
        user_id=current_user.id,
        alarm_time=alarm_time,
        message=alarm_data.message,
        repeat_pattern=alarm_data.repeat_pattern,
        repeat_days=alarm_data.repeat_days
    )
    
    db.add(new_alarm)
    db.commit()
    db.refresh(new_alarm)
    
    # Create Google Calendar event for alarm
    if current_user.telegram_id:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            event_id = await google_calendar_sync.create_alarm_event(current_user, new_alarm)
            if event_id:
                new_alarm.google_event_id = event_id
                db.commit()
        except Exception as e:
            logger.error(f"Error creating Google Calendar event for alarm: {e}")
    
    return new_alarm

@router.put("/{alarm_id}", response_model=AlarmResponse)
async def update_alarm(
    alarm_id: int,
    alarm_data: AlarmUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update an alarm"""
    alarm = db.query(Alarm).filter(
        Alarm.id == alarm_id,
        Alarm.user_id == current_user.id
    ).first()
    
    if not alarm:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alarm not found"
        )
    
    # Update fields
    update_data = alarm_data.dict(exclude_unset=True)
    
    # Handle alarm_time conversion
    if 'alarm_time' in update_data:
        try:
            alarm_time = datetime.fromisoformat(update_data['alarm_time'])
            if alarm_time < datetime.now():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Alarm time must be in the future"
                )
            alarm.alarm_time = alarm_time
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid time format. Use YYYY-MM-DD HH:MM"
            )
    
    # Update other fields
    for field, value in update_data.items():
        if field != 'alarm_time' and hasattr(alarm, field):
            setattr(alarm, field, value)
    
    db.commit()
    db.refresh(alarm)
    
    # Update Google Calendar event if exists
    if alarm.google_event_id:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            await google_calendar_sync.update_alarm_event(current_user, alarm)
        except Exception as e:
            logger.error(f"Error updating Google Calendar event: {e}")
    
    return alarm

@router.delete("/{alarm_id}")
async def delete_alarm(
    alarm_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete an alarm"""
    alarm = db.query(Alarm).filter(
        Alarm.id == alarm_id,
        Alarm.user_id == current_user.id
    ).first()
    
    if not alarm:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alarm not found"
        )
    
    # Delete from Google Calendar first if exists
    if alarm.google_event_id:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            await google_calendar_sync.delete_alarm_event(current_user, alarm.google_event_id)
        except Exception as e:
            logger.error(f"Error deleting Google Calendar event: {e}")
    
    db.delete(alarm)
    db.commit()
    
    return {"message": "Alarm deleted successfully"}

@router.post("/{alarm_id}/snooze")
async def snooze_alarm(
    alarm_id: int,
    minutes: int = 5,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Snooze an alarm for specified minutes"""
    alarm = db.query(Alarm).filter(
        Alarm.id == alarm_id,
        Alarm.user_id == current_user.id
    ).first()
    
    if not alarm:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alarm not found"
        )
    
    # Create a new alarm for snooze
    snooze_time = datetime.now() + timedelta(minutes=minutes)
    
    new_alarm = Alarm(
        user_id=current_user.id,
        alarm_time=snooze_time,
        message=f"⏰ Snooze: {alarm.message}",
        repeat_pattern="ONCE"
    )
    
    db.add(new_alarm)
    db.commit()
    
    return {"message": f"Alarm snoozed for {minutes} minutes", "alarm_id": new_alarm.id}