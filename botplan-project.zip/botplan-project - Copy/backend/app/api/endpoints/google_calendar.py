from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.user import User
from app.api.endpoints.auth import get_current_user
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

@router.get("/oauth")
async def google_oauth_start(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Start Google OAuth flow"""
    # This is a simplified version - you'll need to implement proper OAuth flow
    # using libraries like authlib or google-auth-oauthlib
    
    return {
        "message": "OAuth flow needs to be implemented",
        "instructions": "Use Google OAuth2 flow to get access tokens"
    }

@router.get("/oauth/callback")
async def google_oauth_callback(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Google OAuth callback handler"""
    # Implement OAuth callback logic here
    return {
        "message": "OAuth callback needs to be implemented",
        "user_id": current_user.id
    }

@router.get("/status")
async def get_calendar_sync_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get Google Calendar sync status"""
    # Check if user has connected Google Calendar
    has_connected = False  # This should check from database
    
    # Get sync statistics
    synced_schedules = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.google_event_id.isnot(None)
    ).count()
    
    total_schedules = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id
    ).count()
    
    return {
        "connected": has_connected,
        "synced_schedules": synced_schedules,
        "total_schedules": total_schedules,
        "sync_percentage": (synced_schedules / total_schedules * 100) if total_schedules > 0 else 0
    }

@router.post("/sync-all")
async def sync_all_to_calendar(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Sync all schedules to Google Calendar"""
    schedules = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.google_calendar_sync == True,
        WeeklySchedule.google_event_id.is_(None)
    ).all()
    
    synced_count = 0
    errors = []
    
    for schedule in schedules:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            event_id = await google_calendar_sync.create_schedule_event(current_user, schedule)
            if event_id:
                schedule.google_event_id = event_id
                synced_count += 1
        except Exception as e:
            errors.append(f"Schedule {schedule.id}: {str(e)}")
    
    db.commit()
    
    return {
        "message": f"Synced {synced_count} schedules to Google Calendar",
        "synced_count": synced_count,
        "errors": errors
    }

@router.post("/disconnect")
async def disconnect_calendar(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Disconnect Google Calendar and remove all events"""
    # This would remove all Google Calendar event IDs and potentially delete events
    schedules = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.google_event_id.isnot(None)
    ).all()
    
    removed_count = 0
    errors = []
    
    for schedule in schedules:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            await google_calendar_sync.delete_schedule_event(current_user, schedule.google_event_id)
            schedule.google_event_id = None
            removed_count += 1
        except Exception as e:
            errors.append(f"Schedule {schedule.id}: {str(e)}")
    
    db.commit()
    
    return {
        "message": f"Disconnected Google Calendar and removed {removed_count} events",
        "removed_count": removed_count,
        "errors": errors
    }