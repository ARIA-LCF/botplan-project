from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import time
from app.core.database import get_db
from app.models.user import User
from app.models.schedule import WeeklySchedule
from app.api.endpoints.auth import get_current_user
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic models
class ScheduleCreate(BaseModel):
    day_of_week: int  # 0=شنبه, 1=یکشنبه, ..., 6=جمعه
    start_time: str   # Format: "HH:MM"
    end_time: str     # Format: "HH:MM"
    task_name: str
    task_description: Optional[str] = None
    category: Optional[str] = "general"
    color: Optional[str] = "#2563eb"
    google_calendar_sync: Optional[bool] = True

class ScheduleResponse(BaseModel):
    id: int
    day_of_week: int
    start_time: str
    end_time: str
    task_name: str
    task_description: Optional[str]
    category: str
    color: str
    is_active: bool
    google_event_id: Optional[str]
    google_calendar_sync: bool
    
    class Config:
        from_attributes = True

class ScheduleUpdate(BaseModel):
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    task_name: Optional[str] = None
    task_description: Optional[str] = None
    category: Optional[str] = None
    color: Optional[str] = None
    is_active: Optional[bool] = None
    google_calendar_sync: Optional[bool] = None

@router.get("/", response_model=List[ScheduleResponse])
async def get_schedules(
    day_of_week: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's schedules, optionally filtered by day"""
    query = db.query(WeeklySchedule).filter(WeeklySchedule.user_id == current_user.id)
    
    if day_of_week is not None:
        query = query.filter(WeeklySchedule.day_of_week == day_of_week)
    
    schedules = query.order_by(WeeklySchedule.day_of_week, WeeklySchedule.start_time).all()
    return schedules

@router.get("/week", response_model=List[ScheduleResponse])
async def get_weekly_schedule(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's complete weekly schedule"""
    schedules = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.is_active == True
    ).order_by(WeeklySchedule.day_of_week, WeeklySchedule.start_time).all()
    
    return schedules

@router.post("/", response_model=ScheduleResponse)
async def create_schedule(
    schedule_data: ScheduleCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new schedule"""
    # Convert time strings to time objects
    try:
        start_time = time.fromisoformat(schedule_data.start_time)
        end_time = time.fromisoformat(schedule_data.end_time)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid time format. Use HH:MM"
        )
    
    # Check for time conflicts
    conflicting_schedule = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.day_of_week == schedule_data.day_of_week,
        WeeklySchedule.is_active == True,
        WeeklySchedule.start_time < end_time,
        WeeklySchedule.end_time > start_time
    ).first()
    
    if conflicting_schedule:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Time conflict with existing schedule"
        )
    
    # Create new schedule
    new_schedule = WeeklySchedule(
        user_id=current_user.id,
        day_of_week=schedule_data.day_of_week,
        start_time=start_time,
        end_time=end_time,
        task_name=schedule_data.task_name,
        task_description=schedule_data.task_description,
        category=schedule_data.category,
        color=schedule_data.color,
        google_calendar_sync=schedule_data.google_calendar_sync
    )
    
    db.add(new_schedule)
    db.commit()
    db.refresh(new_schedule)
    
    # Sync with Google Calendar if enabled
    if schedule_data.google_calendar_sync and current_user.telegram_id:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            event_id = await google_calendar_sync.create_schedule_event(current_user, new_schedule)
            if event_id:
                new_schedule.google_event_id = event_id
                db.commit()
        except Exception as e:
            logger.error(f"Error syncing with Google Calendar: {e}")
    
    return new_schedule

@router.put("/{schedule_id}", response_model=ScheduleResponse)
async def update_schedule(
    schedule_id: int,
    schedule_data: ScheduleUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a schedule"""
    schedule = db.query(WeeklySchedule).filter(
        WeeklySchedule.id == schedule_id,
        WeeklySchedule.user_id == current_user.id
    ).first()
    
    if not schedule:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found"
        )
    
    # Update fields
    update_data = schedule_data.dict(exclude_unset=True)
    
    # Handle time conversions
    if 'start_time' in update_data:
        schedule.start_time = time.fromisoformat(update_data['start_time'])
    if 'end_time' in update_data:
        schedule.end_time = time.fromisoformat(update_data['end_time'])
    
    # Update other fields
    for field, value in update_data.items():
        if field not in ['start_time', 'end_time'] and hasattr(schedule, field):
            setattr(schedule, field, value)
    
    db.commit()
    db.refresh(schedule)
    
    # Update Google Calendar event if exists
    if schedule.google_event_id and schedule.google_calendar_sync:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            await google_calendar_sync.update_schedule_event(current_user, schedule)
        except Exception as e:
            logger.error(f"Error updating Google Calendar event: {e}")
    
    return schedule

@router.delete("/{schedule_id}")
async def delete_schedule(
    schedule_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a schedule"""
    schedule = db.query(WeeklySchedule).filter(
        WeeklySchedule.id == schedule_id,
        WeeklySchedule.user_id == current_user.id
    ).first()
    
    if not schedule:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found"
        )
    
    # Delete from Google Calendar first if exists
    if schedule.google_event_id:
        try:
            from app.services.google_calendar_sync import google_calendar_sync
            await google_calendar_sync.delete_schedule_event(current_user, schedule.google_event_id)
        except Exception as e:
            logger.error(f"Error deleting Google Calendar event: {e}")
    
    db.delete(schedule)
    db.commit()
    
    return {"message": "Schedule deleted successfully"}

@router.get("/categories")
async def get_categories():
    """Get available schedule categories"""
    return {
        "categories": [
            {"id": "work", "name": "کار", "color": "#3b82f6"},
            {"id": "study", "name": "مطالعه", "color": "#10b981"},
            {"id": "fitness", "name": "ورزش", "color": "#f59e0b"},
            {"id": "personal", "name": "شخصی", "color": "#8b5cf6"},
            {"id": "urgent", "name": "مهم", "color": "#ef4444"},
            {"id": "general", "name": "عمومی", "color": "#6b7280"}
        ]
    }