from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from datetime import datetime, timedelta
from typing import List, Optional
from app.core.database import get_db
from app.models.user import User
from app.models.analytics import TaskLog
from app.models.schedule import WeeklySchedule
from app.api.endpoints.auth import get_current_user
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic models
class AnalyticsResponse(BaseModel):
    total_tasks: int
    completed_on_time: int
    completed_late: int
    missed: int
    completion_rate: float
    average_response_time: Optional[float]
    most_productive_day: str
    most_common_category: str
    weekly_trend: List[dict]
    daily_completion_chart: List[dict]

class ProductivityStats(BaseModel):
    date: str
    completed: int
    total: int
    productivity_score: float

@router.get("/overview", response_model=AnalyticsResponse)
async def get_analytics_overview(
    days: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get analytics overview for the user"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Get task logs in date range
    task_logs = db.query(TaskLog).filter(
        TaskLog.user_id == current_user.id,
        TaskLog.scheduled_time >= start_date,
        TaskLog.scheduled_time <= end_date
    ).all()
    
    # Calculate basic statistics
    total_tasks = len(task_logs)
    completed_on_time = len([log for log in task_logs if log.status == 'confirmed'])
    completed_late = len([log for log in task_logs if log.status == 'completed_late'])
    missed = len([log for log in task_logs if log.status == 'missed'])
    
    completion_rate = (completed_on_time / total_tasks * 100) if total_tasks > 0 else 0
    
    # Calculate average response time
    confirmed_logs = [log for log in task_logs if log.confirmed_at and log.scheduled_time]
    response_times = []
    for log in confirmed_logs:
        response_time = (log.confirmed_at - log.scheduled_time).total_seconds() / 60  # in minutes
        response_times.append(response_time)
    
    average_response_time = sum(response_times) / len(response_times) if response_times else None
    
    # Find most productive day
    day_stats = {}
    for log in task_logs:
        day_name = log.scheduled_time.strftime('%A')
        day_stats[day_name] = day_stats.get(day_name, 0) + 1
    
    most_productive_day = max(day_stats.items(), key=lambda x: x[1])[0] if day_stats else "No data"
    
    # Find most common category from schedules
    categories = db.query(WeeklySchedule.category).filter(
        WeeklySchedule.user_id == current_user.id
    ).all()
    
    category_count = {}
    for cat in categories:
        category_count[cat[0]] = category_count.get(cat[0], 0) + 1
    
    most_common_category = max(category_count.items(), key=lambda x: x[1])[0] if category_count else "general"
    
    # Weekly trend data
    weekly_trend = []
    for i in range(4):
        week_start = end_date - timedelta(weeks=(3-i))
        week_end = week_start + timedelta(days=6)
        
        week_tasks = [log for log in task_logs if week_start <= log.scheduled_time <= week_end]
        week_completed = len([log for log in week_tasks if log.status == 'confirmed'])
        
        weekly_trend.append({
            "week": f"هفته {i+1}",
            "completed": week_completed,
            "total": len(week_tasks),
            "rate": (week_completed / len(week_tasks) * 100) if week_tasks else 0
        })
    
    # Daily completion chart (last 7 days)
    daily_completion_chart = []
    for i in range(7):
        date = end_date - timedelta(days=(6-i))
        date_str = date.strftime('%Y-%m-%d')
        
        day_tasks = [log for log in task_logs if log.scheduled_time.date() == date.date()]
        day_completed = len([log for log in day_tasks if log.status == 'confirmed'])
        
        daily_completion_chart.append({
            "date": date_str,
            "completed": day_completed,
            "total": len(day_tasks),
            "rate": (day_completed / len(day_tasks) * 100) if day_tasks else 0
        })
    
    return AnalyticsResponse(
        total_tasks=total_tasks,
        completed_on_time=completed_on_time,
        completed_late=completed_late,
        missed=missed,
        completion_rate=round(completion_rate, 2),
        average_response_time=round(average_response_time, 2) if average_response_time else None,
        most_productive_day=most_productive_day,
        most_common_category=most_common_category,
        weekly_trend=weekly_trend,
        daily_completion_chart=daily_completion_chart
    )

@router.get("/productivity")
async def get_productivity_stats(
    days: int = 7,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get detailed productivity statistics"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    productivity_data = []
    
    for i in range(days):
        current_date = start_date + timedelta(days=i)
        date_str = current_date.strftime('%Y-%m-%d')
        
        # Get tasks for this day
        day_tasks = db.query(TaskLog).filter(
            TaskLog.user_id == current_user.id,
            func.date(TaskLog.scheduled_time) == current_date.date()
        ).all()
        
        completed_tasks = len([task for task in day_tasks if task.status == 'confirmed'])
        total_tasks = len(day_tasks)
        
        productivity_score = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        productivity_data.append(ProductivityStats(
            date=date_str,
            completed=completed_tasks,
            total=total_tasks,
            productivity_score=round(productivity_score, 2)
        ))
    
    return productivity_data

@router.get("/category-breakdown")
async def get_category_breakdown(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get breakdown of tasks by category"""
    # Get schedules grouped by category
    category_stats = db.query(
        WeeklySchedule.category,
        func.count(WeeklySchedule.id).label('count')
    ).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.is_active == True
    ).group_by(WeeklySchedule.category).all()
    
    return {
        "categories": [
            {"name": cat, "count": count, "percentage": 0}  # Percentage would need total
            for cat, count in category_stats
        ]
    }

@router.get("/completion-timeline")
async def get_completion_timeline(
    days: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get timeline of task completions"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    timeline_data = []
    
    for i in range(days):
        current_date = start_date + timedelta(days=i)
        date_str = current_date.strftime('%Y-%m-%d')
        
        # Get completed tasks for this day
        completed_tasks = db.query(TaskLog).filter(
            TaskLog.user_id == current_user.id,
            func.date(TaskLog.scheduled_time) == current_date.date(),
            TaskLog.status == 'confirmed'
        ).count()
        
        timeline_data.append({
            "date": date_str,
            "completed_tasks": completed_tasks
        })
    
    return timeline_data