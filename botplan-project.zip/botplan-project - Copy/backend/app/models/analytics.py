from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.core.database import Base

class TaskLog(Base):
    __tablename__ = "task_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # شناسه کار (میتواند از weekly_schedules یا alarms باشد)
    task_id = Column(Integer, nullable=False)
    task_type = Column(String(20), nullable=False)  # 'schedule' یا 'alarm'
    
    # زمان‌بندی و اجرا
    scheduled_time = Column(DateTime(timezone=True), nullable=False)
    executed_time = Column(DateTime(timezone=True), nullable=True)
    
    # وضعیت: pending, reminded, confirmed, missed, cancelled
    status = Column(String(20), default="pending")
    
    # زمان تایید توسط کاربر
    confirmed_at = Column(DateTime(timezone=True), nullable=True)
    
    # اطلاعات اضافی
    notification_count = Column(Integer, default=0)  # تعداد نوتیفیکیشن‌های ارسال شده
    response_time = Column(Integer, nullable=True)  # زمان پاسخ کاربر به ثانیه
    
    # زمان ایجاد
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # رابطه با کاربر
    user = relationship("User", back_populates="task_logs")

    def __repr__(self):
        return f"<TaskLog(id={self.id}, task_type={self.task_type}, status={self.status})>"

# اضافه کردن رابطه به User
from app.models.user import User
User.task_logs = relationship("TaskLog", order_by=TaskLog.scheduled_time, back_populates="user")