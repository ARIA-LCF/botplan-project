from sqlalchemy import Column, Integer, String, Time, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.core.database import Base

class WeeklySchedule(Base):
    __tablename__ = "weekly_schedules"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # روز هفته: 0=شنبه, 1=یکشنبه, ..., 6=جمعه
    day_of_week = Column(Integer, nullable=False)
    
    # زمان شروع و پایان
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    
    # اطلاعات کار
    task_name = Column(String(200), nullable=False)
    task_description = Column(Text, nullable=True)
    category = Column(String(50), default="general")  # work, study, fitness, personal, urgent
    color = Column(String(20), default="#2563eb")  # رنگ برای نمایش در UI
    
    # مدیریت وضعیت
    is_active = Column(Boolean, default=True)
    
    # سینک با Google Calendar
    google_event_id = Column(String(100), nullable=True)
    google_calendar_sync = Column(Boolean, default=True)
    
    # زمان‌های ایجاد و به‌روزرسانی
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # رابطه با کاربر
    user = relationship("User", back_populates="schedules")

    def __repr__(self):
        return f"<WeeklySchedule(id={self.id}, day={self.day_of_week}, task={self.task_name})>"

# اضافه کردن رابطه به User
from app.models.user import User
User.schedules = relationship("WeeklySchedule", order_by=WeeklySchedule.id, back_populates="user")