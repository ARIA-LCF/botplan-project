from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.core.database import Base

class Alarm(Base):
    __tablename__ = "alarms"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # اطلاعات آلارم
    alarm_time = Column(DateTime(timezone=True), nullable=False)
    message = Column(Text, nullable=False)
    
    # الگوی تکرار: ONCE, DAILY, WEEKLY, MONTHLY, YEARLY
    repeat_pattern = Column(String(20), default="ONCE")
    
    # روزهای هفته برای تکرار هفتگی (مثلاً "1,3,5" برای شنبه، دوشنبه، چهارشنبه)
    repeat_days = Column(String(50), nullable=True)
    
    # مدیریت وضعیت
    is_active = Column(Boolean, default=True)
    
    # سینک با Google Calendar
    google_event_id = Column(String(100), nullable=True)
    
    # زمان‌های ایجاد و به‌روزرسانی
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # رابطه با کاربر
    user = relationship("User", back_populates="alarms")

    def __repr__(self):
        return f"<Alarm(id={self.id}, time={self.alarm_time}, message={self.message})>"

# اضافه کردن رابطه به User
from app.models.user import User
User.alarms = relationship("Alarm", order_by=Alarm.alarm_time, back_populates="user")