from app.core.config import settings
from celery.schedules import crontab

# Celery configuration
broker_url = settings.redis_url
result_backend = settings.redis_url

# Timezone
timezone = settings.timezone

# Task routes
task_routes = {
    'app.services.scheduler.check_due_tasks': {'queue': 'scheduler'},
    'app.services.scheduler.cleanup_old_logs': {'queue': 'maintenance'},
}

# Beat schedule
beat_schedule = {
    'check-due-tasks-every-minute': {
        'task': 'app.services.scheduler.check_due_tasks',
        'schedule': crontab(minute='*'),
        'options': {'queue': 'scheduler'}
    },
    'cleanup-old-logs-daily': {
        'task': 'app.services.scheduler.cleanup_old_logs',
        'schedule': crontab(hour=2, minute=0),  # 2 AM daily
        'options': {'queue': 'maintenance'}
    },
}

# Task serialization
task_serializer = 'json'
result_serializer = 'json'
accept_content = ['json']