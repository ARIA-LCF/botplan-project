from app.services.scheduler import celery_app

# This file imports the celery app to make it discoverable
# All tasks are defined in app/services/scheduler.py