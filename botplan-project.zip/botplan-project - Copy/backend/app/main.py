from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import logging
import os
from dotenv import load_dotenv

from app.core.database import engine, Base, get_db
from app.core.config import Settings
from app.api.endpoints import auth, schedules, alarms, analytics, google_calendar
from app.services.telegram_bot import start_bot, stop_bot

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Creating database tables...")
    Base.metadata.create_all(bind=engine)
    
    logger.info("Starting Telegram bot...")
    await start_bot()
    
    yield
    
    # Shutdown
    logger.info("Stopping Telegram bot...")
    await stop_bot()

app = FastAPI(
    title="BotPlan API",
    description="Personal Schedule Planner with Telegram Integration",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(schedules.router, prefix="/api/schedules", tags=["Schedules"])
app.include_router(alarms.router, prefix="/api/alarms", tags=["Alarms"])
app.include_router(analytics.router, prefix="/api/analytics", tags=["Analytics"])
app.include_router(google_calendar.router, prefix="/api/calendar", tags=["Google Calendar"])

@app.get("/")
async def root():
    return {"message": "BotPlan API is running!", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": "2024-01-01T00:00:00Z"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True if os.getenv("DEBUG") == "true" else False
    )