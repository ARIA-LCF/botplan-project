-- Initialize database with extensions and basic setup
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create additional indexes for performance
CREATE INDEX IF NOT EXISTS idx_schedules_user_day ON weekly_schedules(user_id, day_of_week);
CREATE INDEX IF NOT EXISTS idx_schedules_time ON weekly_schedules(start_time, end_time);
CREATE INDEX IF NOT EXISTS idx_alarms_user_time ON alarms(user_id, alarm_time);
CREATE INDEX IF NOT EXISTS idx_task_logs_user_date ON task_logs(user_id, scheduled_time);